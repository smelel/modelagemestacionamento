## Controle Estacionamento
### Sistema de Controle do Estacionamento do IFSul Passo Fundo

## Diagrama de classes
